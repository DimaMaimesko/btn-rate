<?php
namespace Codeception\Test\Interfaces;

/**
 * TestCases that do not follow OOP
 */
interface Plain
{
}
