<?php
namespace Codeception\Exception;

class ConnectionException extends \RuntimeException
{
}
