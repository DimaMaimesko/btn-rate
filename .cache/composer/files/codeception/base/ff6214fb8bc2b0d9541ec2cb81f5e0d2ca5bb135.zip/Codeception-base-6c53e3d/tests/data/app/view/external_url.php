<html>
<body>
    <a href="http://codeception.com/">Next</a>
</body>
</html>